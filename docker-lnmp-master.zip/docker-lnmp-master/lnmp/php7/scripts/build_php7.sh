#!/bin/bash
docker build --tag addcn/php7 -f php7/Dockerfile .