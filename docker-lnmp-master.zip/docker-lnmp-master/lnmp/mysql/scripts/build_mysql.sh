#!/bin/bash
docker build --tag addcn/mysql -f mysql/Dockerfile .