#!/bin/bash
docker build --tag addcn/nginx -f nginx/Dockerfile .